# Software Development Plan

## Phase 0: Requirements Specification *(10%)*

* The goal of the Big Data project is to create a program that summarizes and formats labor statistics from large csv and text files.

* The program needs to pick out the relavant data from the large files and print it in the right format.

* A good solution will be able to take files as input, read through the files, and produce summaries that exactly match the example output. Summaries should include relavant information such as wages, number of establishments, and employment level.

* I already know how to read through files and pick out fields from csv files.

* I might have a challenge incorporating the FIPS area codes. The instructions recommend that I use a python dictionary to hold the data, but I don't have much experience with dictionaries.

* I might also have a challenge with keeping the memory usuage down. The files are pretty big so loading all of the data in incorrectly will cause problems. I just need to read the files line by line and make sure unused references are overwritten or go out of scope.

* Testing the program with all of the data might also be challenging just because of how large some of the files are.

## Phase 1: System Analysis *(10%)*

* The program will accept a single argument: the name of a directory
containing CSV files.

* The output will be a formated report of the statistics for the csv file provided.
* The program depends on csv filenames. (They are hard coded)

## Key Functions

*   isIncludedFIP( fipCode) # checks if area code should be included
    * Output : true if the fip area code should be included, false if the code should not be included.
    * Function will check to see if the fip area code from 'area-titles.csv' should be included.

*   getIncludedFipsAreas () # no inputs. You could call the path to all-titles.csv input, but it will be hardcoded.
    * Output : Dictionary with ALL of the FIPS codes from all-titles.csv. Value of each key will be the area_title.
    * Function will loop through the lines of all-titles.csv. if isIncludedFIP(FIPS area) it will add the FIPS area as a key to a dictionary with the area_title of the area as its value.

*   getMaxStat(group, stat) # group is the group of areas that you want to get the max stat out of (All industry, Software Publishing). Stat is the name of the field that you want to find the max of (annualEstablishments, annualWages, annualEmployment) 
    * Output : A list with the (area with the highest stat, the highest stat)
    * Function will loop over each area in group and find the one with the max stats and return the area and stat in a list.

*   getIndustryStats(industryCode, ownCode, directory)
    * Output : A list of dictionaries that contain the stats of each area in the industry
    * Function will loop over lines in directory/2021.annual.singlefile.csv and append the stats of each area to a list and then return that list.

## Phase 2: Design *(30%)*

## isIncludedFIP ( fipCode : string)
```
def isIncludedFIP(fipCode):
    if fipCode ends in '000': #statewide
        return false
    elif fipCode starts with 'US': # US Combined
        return false
    elif fipCode starts with 'C': # MSAs CSAs and MicroSAs
        return false
    elif fipCode starts with 'M': #MSAs
        return false
    elif fipCode is '57000': #
        return false
    
    If fipCode matches none of the above:
        return true       
```
## getIncludedFipsAreas (directory : string)
```
def getIncludedFipsAreas():
    create variable includedFIPS as an empty dictionary to hold included FIPS Codes and titles
    open 'directory/area-title.csv' file
    for each line in the file:
        split the line by commas with a max split of 1 # avoid splitting the comma in area-title ex: Dale County, Alabama
    
        get fips_code from splitline
        remove quotation marks from fips_code
        
        if isIncludedFIP(fips_code):     
            get area_title from splitline
            remove quotation marks from area_title
            add fips_code as key to dictionary with area_title as value
    close file
    return includedFIPS
```
## getIndustryStats( industryCode : string, ownCode : string, directory : string)
```
def getIndustryStats(industryCode, ownCode, directory):
    get included fips from getIncludedFipsAreas()
    group = empty list
    open 'directory/2021.annual.singlefile.csv'
    for each line in file:
        if first line: # avoid column titles
            continue loop # just skip the first line
        
        split line by commas

        get area_fip from splitLine
        remove commas from ends of area_fips
        
        if area_fip is not in includedFips: #if not included fip
            continue loop # skip the rest of the iteration

        get area_industryCode from splitLine
        remove commas from ends of area_industryCode

        if area_industryCode is not industryCode: # if not industry code (10 for all, 5112 for software)
            continue loop

        get area_ownCode from splitLine
        remove commas from area_ownCode

        if area_ownCode is not ownCode: # 
            continue loop

        get area_annualEstablishments from splitLine #these all come as strings
        get area_annualWages from splitLine
        get area_annualEmployment from splitLine

        create area as a dictionary with all of the information inside
        group.append(area)
    close file
```
## totalStat(group : list, stat : string)
```
def totalStat(group, stat):
    initialize total as 0
    for each area in the group:
        add area[stat] to total
    return total
```
## getMaxStat(group : list, stat : string)
```
def getMaxStat(group, stat):
    intialize max as 0
    intialize max_area as None
    for each area in the group:
        if area[stat]>max:
            change the max to that area[stat]
            change max_area to current area
    return max_area's fip code and the max value
```

## Phase 3: Implementation *(15%)*s

* Changed getMaxStats to return list instead of tuple. This worked better because the report object is already set up to take that information as a list.
* Learned how to use .strip() to remove commas and newlines from strings. This was really useful for processing the text from the 2021.annual.singlefile.csv
* Implementation went swimmingly. I spent a lot of time in my design phase so I only tweaked a few things here and there and followed the design pretty closely.


## Phase 4: Testing & Debugging *(30%)*
* Testing for invalid argument length:
```
python src/bigData.py
Usage: python src/bigData.py DIRECTORY
FILE should be a directory containing csv files
```
	* Program works as intended by displaying a usage message and exiting with error code 1.

* Testing for non existant files and directories:
```
python src/bigData.py DNE_FILE
Reading the databases...
Traceback (most recent call last):
  File "src/bigData.py", line 140, in <module>
    allIndustry = getIndustryStats("10","0",directory)
  File "src/bigData.py", line 72, in getIndustryStats
    includedFipsAreas = getIncludedFipsAreas(directory)
  File "src/bigData.py", line 55, in getIncludedFipsAreas
    file = open(f'{directory}/area-titles.csv')
FileNotFoundError: [Errno 2] No such file or directory: 'DNE_FILE/area-titles.csv'
```
	* Program crashes on attempting to open csv files within the given directory. This is intended behavior.

## Bugs
* bug: function getMaxStat was trying to return stats from a non-existant area.
* fix: changed initial value of maxArea from none to group[0]. Reason this was a problem is because if the first area was the maxArea, the function would attempt to return None, which was the original intial value of maxArea.
```
$ python src/bigData.py data/DC_software_industry/
Reading the databases...
Done in 0.073 seconds!
0
Traceback (most recent call last):
  File "C:\Users\camer\Documents\cs1440-allen-cameron-assn3\src\bigData.py", line 161, in <module>
    rpt.all.max_annual_wage    = getMaxStat(allIndustry,"annualWages")
  File "C:\Users\camer\Documents\cs1440-allen-cameron-assn3\src\bigData.py", line 127, in getMaxStat
    return [maxArea["area_title"],maxValue]
TypeError: 'NoneType' object is not subscriptable
```
* bug: trying to get stats of empty industries from getMaxStats causes index out of range with 'maxArea = group[0]' This is because the getMaxStats function uses the first index of the given group as the starting max area. If the area is empty, it tries to reference a non existent area.
* fix: added line in getMaxStats that checks length of group. If 0 then return an empty area title and 0 for the value.
```
$ python src/bigData.py data/DC_software_industry/
Reading the databases...
Done in 0.031 seconds!
0
Traceback (most recent call last):
  File "C:\Users\camer\Documents\cs1440-allen-cameron-assn3\src\bigData.py", line 161, in <module>
    rpt.all.max_annual_wage    = getMaxStat(allIndustry,"annualWages")
  File "C:\Users\camer\Documents\cs1440-allen-cameron-assn3\src\bigData.py", line 122, in getMaxStat
    maxArea =  group[0]
IndexError: list index out of range
```
* bug: isIncludedFip was not correctly excluding all MSAs,CSAs,MicroSAs because it was slicing the string incorrectly.
* fix: changed isIncludedFip to use fipCode.endswith() and fipCode.startswith() to check if the fipCode should be included.
```
$ python src/bigData.py data/USA_full

Statistics over all industries in 2021:
=========================================================
Number of FIPS areas in report       4,267
# 4,267 is not correct. The program was not correctly excluding all non-included fips. It should be 3,274.
```

## Phase 5: Deployment *(5%)*

* deployed.

## Phase 6: Maintenance

* I think part of my getIndustryStats function could have been written better. I tend to use multiple exit or skip points in my functions or loops, and this can make it harder to read. There was probably a better way to skip over the non-included areas in getIndustryStats.
* I understand how my whole program works. I wrote everything in the program except for the report class. It took me a while to understand how the report class works. Once I figured it out, I was able to structure my own functions around it. One thing that I'm not entirely sure about is iterable objects. I used the open files as iterable objects in my program and I'm not sure if this is the best practice. It made it really convient to skip the first line and to read the files one by one, so it seems to work pretty well for what I was using it for, even though I don't fully understand how iterable objects work.
* If a bug was reported in a few months, It would take me a day or two to find the cause and fix the bug. This is just because the program uses a lot of loops and is fairly complex.
* I include a lot of notes in my documentation that help explain why each part of the program does what it does. I think that this helps the documentation make more sense. My documentation makes sense and everyone should be able to understand it. My documentation will also make sense to me in 6 months because I keep it organized and up to date with the program.
* It would be really it easy to add a new feature to this program in a year. The way I designed the program is pretty modular, meaning that each major step is broken down into functions. Having these different functions would allow me to more easily incorporate new functions and features.
* My program, as per the instructions, is dependant on the specific csv file names. If certain hardware or operating system changed the ways directories or file names worked, that could cause my program to stop working.
* Other than that, my program should work on all future python versions, capable hardware, and operating systems.