
| Date         | Time Spent | Events
|--------------|------------|--------------------
| Oct 4        |   1 hour   | Worked on and finished shell tutor lessons.
| Oct 8        | 0.5 hours  | Finished phase 0 of plan. Also read through instructions again.
| Oct 9        | 1.5 hours  | Finished phase 1 of plan. Tagged Analyzed on commit.
| Oct 10       |   1 hour   | Worked on phase 2.
| Oct 11       | 1.5 hours  | Finished phase 2 and implemenation.
| Oct 12       | 1.5 hours  | Finished implementation and testing.
| Oct 13       |   1 hour   | Finished plan, reviewed code, and deployed final version.
| TOTAL        |   8 hours  |


