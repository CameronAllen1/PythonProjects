import time  	    	       
import sys  	    	       
from Report import Report  	    	       


rpt = Report(year=2021)  	    	       

# Cameron Allen
def isIncludedFip(fipCode):
    if fipCode.endswith('000'): #statewide
        return False
    elif fipCode.startswith('US'): # US Combined
        return False
    elif fipCode.startswith('C'): # MSAs CSAs and MicroSAs
        return False
    elif fipCode.startswith('M'): #MSAs
        return False
    elif fipCode == '57000': #FBI - Undesignated
        return False

    return True


def getIncludedFipsAreas(directory):
    includedFIPS = {}
    file = open(f'{directory}/area-titles.csv')
    next(file) # skip first line with column titles. next(iterable) allows me to move past the first element
    for line in file: #an open file is an iterable object

        splitLine = line.strip().split(',',1) # I do this all in one line so that only one line of the file is kept in memory at once. This strips the newline off the end and splits the line by commas

        fips_code = splitLine[0].strip('"')# strip removes quotation marks from ends

        if isIncludedFip(fips_code):
            area_title = splitLine[1].strip('"') # removes quotation marks

            includedFIPS[fips_code] = area_title
    file.close()
    return includedFIPS


def getIndustryStats(industryCode, ownCode, directory):
    includedFipsAreas = getIncludedFipsAreas(directory)

    group = []

    file = open(f'{directory}/2021.annual.singlefile.csv')
    next(file) # skip first line with column titles. next(iterable) allows me to move past the first element
    for line in file:
        splitLine = line.strip().split(',') # I do this all in one line so that only one line of the file is kept in memory at once. This strips the newline off the end and splits the line by commas
        
        area_fip = splitLine[0].strip('"') 

        if not(area_fip in includedFipsAreas):
            continue
        
        area_industryCode = splitLine[2].strip('"')
        if not(area_industryCode == industryCode): # this is not the industry we are looking for
            continue

        area_ownCode = splitLine[1].strip('"')

        if not(area_ownCode == ownCode):
            continue

        area_annualEstablishments = splitLine[8]
        area_annualWages = splitLine[10]
        area_annualEmployment = splitLine[9]

        area = {}
        area["fip_code"] = area_fip
        area["area_title"] = includedFipsAreas[area_fip]
        area["industry_code"] = area_industryCode
        area["own_code"] = area_ownCode
        area["annualEstablishments"] = area_annualEstablishments
        area["annualWages"] = area_annualWages
        area["annualEmployment"] = area_annualEmployment
        group.append(area)
    file.close()
    return group

def totalStat(group, stat):
    total = 0
    for area in group:
        total = total + int(area[stat])
    return total # list with (fip code, stat total)

def getMaxStat(group, stat):
    if len(group)==0: # just return empty stats if an empty group is given
        return ['',0]
    maxValue = 0
    maxArea =  group[0]
    for area in group:
        if int(area[stat])>maxValue:
            maxValue = int(area[stat])
            maxArea = area
    return [maxArea["area_title"],maxValue]



if __name__ == '__main__':  

    if (len(sys.argv)<2):
        print("Usage: src/bigData.py DATA_DIRECTORY")
        sys.exit(1)

    print("Reading the databases...", file=sys.stderr)  	    	       
    before = time.time()  	    	       

    directory = sys.argv[1]
    allIndustry = getIndustryStats("10","0",directory)
    softIndusty = getIndustryStats("5112","5",directory)

    after = time.time()  	    	       
    print(f"Done in {after - before:.3f} seconds!", file=sys.stderr)  	    	       

    rpt.all.num_areas          = len(allIndustry)
    rpt.all.total_annual_wages = totalStat(allIndustry,"annualWages")
    rpt.all.max_annual_wage    = getMaxStat(allIndustry,"annualWages")	    	       

    rpt.all.total_estab         = totalStat(allIndustry,"annualEstablishments")  	    	       
    rpt.all.max_estab           = getMaxStat(allIndustry,"annualEstablishments")

    rpt.all.total_empl          = totalStat(allIndustry,"annualEmployment")  	    	       
    rpt.all.max_empl            = getMaxStat(allIndustry,"annualEmployment")  	    	       

 	    	       
    rpt.soft.num_areas          = len(softIndusty) 	    	       
    rpt.soft.total_annual_wages = totalStat(softIndusty,"annualWages")  	    	       
    rpt.soft.max_annual_wage    = getMaxStat(softIndusty,"annualWages")


    rpt.soft.total_estab        = totalStat(softIndusty,"annualEstablishments")  	    	       
    rpt.soft.max_estab          = getMaxStat(softIndusty,"annualEstablishments")

    rpt.soft.total_empl         = totalStat(softIndusty,"annualEmployment")  	    	       
    rpt.soft.max_empl           = getMaxStat(softIndusty,"annualEmployment")  	    	       
	    	       
    print(rpt)    	       
