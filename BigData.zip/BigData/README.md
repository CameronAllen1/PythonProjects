## Big Data Processing!
This is a program that I wrote that can read through and summarize mulitple large csv files.
This is useful for analyzing data and drawing conclusions from large data sets.

Documentation for the project can be found in the Doc folder.

To run the program :
```
src/bigData.py [DATA_DIRECTORY]
```
DATA_DIRECTORY is the path of a directiory that contains csv files.