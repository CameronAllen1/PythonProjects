# BLS Quarterly Census of Employment and Wages

This document describes the meaning of the columns in this file:

[QCEW Field Layouts for NAICS-Based, Annual CSV Files](https://data.bls.gov/cew/doc/layouts/csv_annual_layout.htm)

## FIPS area codes

This document explains how the FIPS area codes are constructed:

[QCEW Area Code Guide](https://data.bls.gov/cew/doc/titles/area/area_guide.htm)
